Changes in clustering params:
1) change random number see from 23705 for 899231