﻿(* File ListC/ParseAndComp.fs *)

let fromString = Parse.fromString

let fromFile = Parse.fromFile

let compileToFile = Comp.compileToFile