(* File MicroC/ParseAndContcomp.fs *)

let fromString = Parse.fromString

let fromFile = Parse.fromFile

let contCompileToFile = Contcomp.contCompileToFile
